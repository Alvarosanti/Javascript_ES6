// LAN ESPAÑOL

/*
¿Qué es la programación orientada a objetos y por qué la usaría?
La programacion orientada a objetos es, una forma o modelo de programacion con guias,
esta basado en clases y objetos. 
Mayormente se utiliza para estructurar programas de software reutilizables.

¿En qué casos un patrón OOP sería una mejor opción?
Cuando necesitemos reutilizar el codigo, tiene una estructura simple tambien permite el encapsulamiento.
Describe el flujo de la aplicación desde el punto de vista del usuario (historias de usuario).
¿Cuál es el propósito de la aplicación y cómo la usarían las personas? ¿Qué información ingresarían y qué recibirían?
Intente mencionar todas las "historias" en las que el usuario realiza algún tipo de operación CRUD.

Una aplicacion de venta de moldura decorativas
El usuario puede acceder a la pagina sin iniciar sesion, para poder realizar una compra necesita inciar seision, por lo que el 
programa le permitira registrarse, editar su cuenta de usuario.
El programa muestra los modelos de productos, puede guardar en favoritos como tambien agregarlos directamente al carrito de compra.
Puede realizar la compra directamente basando en el stock del producto.
El administrador puede actulizar el stock, como tambien habilitar o deshabilitar algun producto, puede editar y agregar un nuevo producto de ser necesario.
El Vendedor revisa que el pago este correctamente y autoriza la venta.

*/
